# cubes 2 classes > null-added
https://universe.roboflow.com/nytc/cubes-2-classes

Provided by a Roboflow user
License: CC BY 4.0

